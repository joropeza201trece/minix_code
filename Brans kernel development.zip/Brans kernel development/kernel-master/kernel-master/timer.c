#include "system.h"

/*


The Programmable Interval Timer (PIT, model 8253 or 8254), also called the System Clock, 
is a very useful chip for accurately generating interrupts at regular time intervals. 
The chip itself has 3 channels: Channel 0 is tied to is tied to IRQ0, 
to interrupt the CPU at predictable and regular times, Channel 1 is system specific, 
and Channel 2 is connected to the system speaker. As you can see, 
this single chip offers several very important services to the system.

The only channels that you should every be concerned with are Channels 0 and 2. 
You may use Channel 2 in order to make the computer beep. In this section of the tutorial, 
we are only concerned with Channel 0 - mapped to IRQ0. 
This single channel of the timer will allow you to accurately schedule new processes later on, 
as well as allow the current task to wait for a certain period of time (as will be demonstrated shortly). 
By default, this channel of the timer is set to generate an IRQ0 18.222 times per second. 
It is the IBM PC/AT BIOS that defaults it to this. 
A reader of this tutorial has informed me that this 18.222Hz tick rate was used in order for the tick count to cycle at 0.055 seconds.
 Using a 16-bit timer tick counter, the counter will overflow and wrap around to 0 once every hour.

To set the rate at which channel 0 of the timer fires off an IRQ0, we must use our outportb function to write to I/O ports. 
There is a Data register for each of the timer's 3 channels at 0x40, 0x41, and 0x42 respectively, and a Command register at 0x43. 
The data rate is actually a 'divisor' register for this device. 
The timer will divide it's input clock of 1.19MHz (1193180Hz) by the number you give it in the data register 
to figure out how many times per second to fire the signal for that channel. You must first select the channel 
that we want to update using the command register before writing to the data/divisor register. 
What is shown in the following two tables is the bit definitions for the command register, as well as some timer modes.


/*

The programmable interval timer is a chip connected to IRQ0. 
It can interrupt the CPU at a user-defined rate (between 18.2Hz and 1.1931 MHz). 
The PIT is the primary method used for implementing a system clock
 and the only method available for implementing multitasking (switch processes on interrupt).

The PIT has an internal clock which oscillates at approximately 1.1931MHz. 
This clock signal is fed through a frequency divider, 
to modulate the final output frequency. It has 3 channels, 
each with it's own frequency divider.

*/
unsigned long timer_ticks = 0;

void timer_phase(int hz)
{
    int divisor = 1193180 / hz;       /* Calculate our divisor */
    outportb(0x43, 0x36);             /* Set our command byte 0x36 */
    outportb(0x40, divisor & 0xFF);   /* Set low byte of divisor */
    outportb(0x40, divisor >> 8);     /* Set high byte of divisor */
}

void timer_handler(struct regs *r)
{
    timer_ticks++;
}

void timer_install(void)
{
    irq_install_handler(0, timer_handler);
}

void timer_wait(int ticks)
{
    unsigned long eticks;

    eticks = timer_ticks + ticks;
    while(timer_ticks < eticks);
}

unsigned long uptime(void)
{
	return (timer_ticks / 18);
}
