#include "system.h"

/* IDT is pretty much the same in coding as GDT table */

/*   
En modo protegido , el IDT es una matriz de descriptores almacenados consecutivamente en la memoria 
e indexados por un vector de interrupci�n. Un IDT completamente poblado tiene 2  KB en modo protegido 
de 32 bits (256 entradas de 8 bytes cada una) de longitud y 4  KB en modo protegido de 64 bits (256 entradas de 16 bytes cada una). 
No es necesario utilizar todas las entradas posibles: basta con rellenar el IDT hasta el vector de interrupci�n m�s alto utilizado 
y establecer la parte de longitud del IDT IDTR correspondiente. Tabla de descriptores de interrupci�n.
Las interrupciones pueden ser provocadas por hardware o bien por software. Las interrupciones por hardware, pueden ser enmascarables y no enmascarables.
Los sistemas basados en microprocesador como el de Intel, pueden gestionar hasta 256 interrupciones.
Las interrupciones de software son generadas utilizando la instrucci�n INT. 

*/
struct idt_entry
{
    unsigned short base_lo;		// bits de offset 0..15. The lower 16 bits of the address to jump to when this interrupt fires.
    unsigned short sel;			// un selector de segmento en la GDT o IDT.  Kernel segment selector.
    unsigned char always0;		// no se utiliza, se establece a 0
    unsigned char flags;		// type and attributes, see below
    							//  7                              0
								//	+---+---+---+---+---+---+---+---+
								//	| P |  DPL  | S |    GateType   |
								//	+---+---+---+---+---+---+---+---+
    unsigned short base_hi;		// bits de offset 16..31.  The upper 16 bits of the address to jump to.
} __attribute__((packed));

/*El IDT en modo protegido puede residir en cualquier lugar de la memoria f�sica. El procesador tiene un registro especial (IDTR)
 para almacenar tanto la direcci�n base f�sica como la longitud en bytes del IDT. Cuando ocurre una interrupci�n, el procesador 
 multiplica el vector de interrupci�n por el tama�o del descriptor y agrega el resultado a la direcci�n base IDT. 
 Con la ayuda de la longitud de IDT, se verifica que la direcci�n de memoria resultante est� dentro de la tabla; si es demasiado grande, 
 se genera una excepci�n. Si todo est� bien, se carga el descriptor almacenado en la ubicaci�n de memoria calculada y se toman acciones 
 de acuerdo con el tipo y contenido del descriptor. Tabla de descriptores de interrupci�n
*/

/*
la tabla est� formada por un vector de descriptores de 8 bytes (en modo protegido). Para indexar la IDT
el procesador escala el vector de 8 en 8 (bytes x descriptor). Puesto q s�lo existen 256 vectores de interrupci�n
la IDT contendr� 256 posiciones como m�ximo, de hecho suele contener menos, ya que s�lo se necesitan los descriptores
de las interrupciones o excpeciones que ocurran cada cierto tiempo. Todos los descriptores que no tienen asignaci�n
(est�n vac�os) tienen el flag puesto a 0
*/

/*la abstracci�n del registro IDTR del procesador de INTEL */
 /*Como la tabla IDT tiene direcci�n lineal de inicio y longitud, se tiene q indicar esta informaci�n
al procesador para q �sta sea almacenada dentro del registro IDTR. La carga de este registro es muy particular
y requiere q ambos par�metros est�n en memoria, en una estructura denominada imagen de IDTR.
En esta estructura, primero se ubican los dos bytes del l�mite y luego los 4 bytes de la base.
Especificados en el formato little-endian.
*/
struct idt_ptr
{
    unsigned short limit;  /*tama�o de 16 bits*/
    unsigned int base;		/*tama�o de 32 bits */
} __attribute__((packed));

/* Aqu� se observa como se trabaja con los 256 entradas de la IDT
A su vez, se observa la creaci�n del apuntador a la idpt*/

struct idt_entry idt[256];
struct idt_ptr idtp;

/* This exists in 'start.asm', and is used to load our IDT */
extern void idt_load(void);

void idt_set_gate(unsigned char num, unsigned long base, unsigned short sel, unsigned char flags)
{
    idt[num].base_lo = (base & 0xFFFF);
    idt[num].base_hi = (base >> 16) & 0xFFFF;
    idt[num].sel = sel;
    idt[num].always0 = 0;
    idt[num].flags = flags;
}

void idt_install(void)
{
    /* Sets the special IDT pointer up like in gdt.c */
    idtp.limit = (sizeof (struct idt_entry) * 256) - 1;
    idtp.base = (unsigned int)&idt;

    /* Clear out the entire IDT, set all to 0 */
    memset(&idt, 0, sizeof(struct idt_entry) * 256);

    /* Here may go additional errors handlings in future */

    idt_load();
}
		
