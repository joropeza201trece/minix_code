#include "system.h"
//La siguiente estructura es una abstracci�n de la forma en la que el procesador de Intel 
//tiene definido a un descritor dentro de la GDT y que la conforma.
//Recordar q cada descriptor es un elemento de 64 bits o de 8 bytes perfectamente definido para la
//arquitectura del procesador IA32 y que tiene como objetivo apuntar a las localidades de memoria
//para gestionar los segmentos de c�digo, datos, stack, extra, fs y gs de sus registros selectores
//que conforman a la arquitectura
//Generalmente la GDT contiene los segmentos de c�digo y datos usados por el sistema operativo y los TSS  y los descriptores para las LDT en un sistema.
//La primera entrada de la GDT corresponde al selector nulo y no se usa.



struct gdt_entry
{
	unsigned short limit_low;
	unsigned short base_low;
	unsigned char base_middle;
	unsigned char access;
	unsigned char granularity;
	unsigned char base_high;

} __attribute__((packed));
 
 /* la abstracci�n a nivel de software del GDTR del procesador de Intel*/
 
 /*Como la tabla GDT tiene direcci�n lineal de inicio y longitud, se tiene q indicar esta informaci�n
al procesador para q �sta sea almacenada dentro del registro GDTR. La carga de este registro es muy particular
y requiere q ambos par�metros est�n en memoria, en una estructura denominada imagen de GDTR.
En esta estructura, primero se ubican los dos bytes del l�mite y luego los 4 bytes de la base.
Especificados en el formato little-endian.
*/

struct gdt_ptr
{
	
	unsigned short limit; 	/*tama�o de 16 bits */
	unsigned int base;		/*tama�o de 32 bits */

} __attribute__((packed));
 
 /* Aqu� se observa como se crea una instacia al registro GDTR
 As� como la generaci�n de 3 GDTs dentro de la memoria de la m�quina*/
 
struct gdt_entry gdt[3];
struct gdt_ptr gp;
/*
Se realiza la llamada a la funcipon gdt_flush Hacer fluir la GDT

C�digo colocado en el archivo start.asm

[global gdt_flush]	;; Allows the C code to call gdt_flush()
[extern gp]
gdt_flush:
	lgdt [gp]         	; Load the GDT with our '_gp' which is a special pointer, Load the new GDT pointer
						; La instrucci�n LGDT carga (Load) la base y el l�mite de la tabla de descriptores globales,
    	mov ax, 0x10    ; 0x10 is the offset in the GDT to our data segment, 0x10 es igual a 16, esto quiere decir que ax
    					; contiene el offset del segmento de datos, las siguientes instrucciones indican que los selectores
    					; ds, es, fs, gs y ss apuntan a la localidad de memoria de memoria de donde se ubica el tercer descriptor
    					; de la GDT que se defini� en kmain.c al llamar a la funci�n init_gdt.


Una vez que se completan las im�genes, se procede a la carga de este registro especial, especificando como par�metro
el apuntador a la imagen, mediante la instrucci�n lgdt que se encuentra codificada en lenguaje ensamblador, 
dentro del archivo start.asm.

*/

void gdt_flush(void); /* This one is in start.asm in fact */
 
 /*
Cada entrada dentro de la tabla de GDT se denomina como compuerta. 
 */
 
void gdt_set_gate(int num, unsigned long base, unsigned long limit, unsigned char access, unsigned char gran)
{
	gdt[num].base_low = (base & 0xFFFF);
	gdt[num].base_middle = (base >> 16) & 0xFF;
	gdt[num].base_high = (base >> 24) & 0xFF;
 
	gdt[num].limit_low = (limit & 0xFFFF);
	gdt[num].granularity = ((limit >> 16) & 0x0F);
 
	gdt[num].granularity |= (gran & 0xF0);
	gdt[num].access = access;
}

void gdt_install(void)
{
	gp.limit = (sizeof(struct gdt_entry) * 6) - 1;  //Esta variable es la cantidad de descriptores dentro de la GDT que un proceso requiere para su ejecuci�n
													//Se considera que cada proceso (en este caso el kernel) requiere de utilizar los registros
													//de CS, DS, SS, ES, FS y GS, proporcionados por el procesador X86.
													//La tabla de descriptores Globales cuenta con un total de 8192 descriptores, enumerados del 0 al 8191. 
													//Entonces, la variable limit del apuntador de descritores globales del proceso, en este caso indica
													//como l�mite dentro de esa tabla el valor de 7
	gp.base = (unsigned int)&gdt;					//Esta variable indica la direcci�n base en donde est� ubicado el primer descriptor de la GDT, que es
													//en donde se ubica el primer descriptor asociado al kernel.
													//Para obtener su valor, se toma la direcci�n de la estructura de la GDT, descrita previamente
													//A partir de esa direcci�n de memoria, se coloca la GDT, siendo los primeros ocho descriptores los asociados
													//al primer proceso del SO, en este caso el kernel
													//Tras la ejecuci�n del programa, la localidad de memoria es 0x00407A30. Este valor es el obtenido tras
													//la ejecuci�n del programa en una laptop, por lo que este valor no es la locadlidad de memoria en donde
													//se resguarda la GDT para el caso del kernel cuando arranca en la m�quina

//Generalmente la GDT contiene los segmentos de c�digo y datos usados por el sistema operativo y los TSS  y los descriptores para las LDT en un sistema.
//La primera entrada de la GDT corresponde al selector nulo y no se usa.

	gdt_set_gate(0, 0, 0, 0, 0);					//Se manda a llamar a la funci�n gdt_set_gate en 3 ocasiones, el primero es un segmento NULL, este ocupa
													//los primeros 8 bytes de la GDT
	gdt_set_gate(1, 0, 0xFFFFFFFF, 0x9A, 0xCF);		//Se indica el segmento de c�digo 1001 1010, este descriptor ocupa el offset 0x08 de la GDT, 
	gdt_set_gate(2, 0, 0xFFFFFFFF, 0x92, 0xCF);		//Se indica el segmento de datos  1001 0010, este descriptor ocupa el offset 0x10 de la GDT
 
	gdt_flush();									//Esta funci�n se encuentra codificada dentro del archivo start.asm, y se defini� como una etiqueta GLOBAL
													//al realizar el enlazado con el compilador de gcc se procede a considerar a dicha funci�n como que
													//puede ser llamada desde cualquier parte del proyecto
													//El contenido de dicha funci�n, hace uso de la instrucci�n LGDT que con el valor asignado a la variable
													//gp del tipo gd_ptr, definida en este programa y colocada como externa en el c�digo de ensamblador
													//como la variable gp ya tiene valores, �stos son suminostrados a la funci�n gdt_flush para que se 
													//invoque a la instrucci�n de ensamblador lgdt, la cual carga (Load) la base y el l�mite 
													//de la tabla de descriptores globales 
}
