#include <stdio.h>
#include <string.h>

//void *memcpy(void *dest, void const *src, int count)
//{   
//    /* Copies memory from src to dest */
//    char *d = dest; char const *s = src;
//    while (count-- > 0) *d++ = *s++; return dest;    
//}
//
//void *memset(void *dest, int val, int count)
//{   
//    /* Memory set in 32-bytes env */
//    register char *d = dest;
//    while (count-- > 0) *d++ = val; return dest;   
//}
//
//
//void *memsetw(void *dest, short int val, int count)
//{   
//    /* Memory set in 16-bytes env */
//    register char *d = dest;
//    while (count-- > 0) *d++ = val; return dest;   
//}
//
//int strlen(const char *s)
//{   
//    /* Return length of a given string */
//    int n; n = 0; while (*s++) n++; return n;    
//}
//
//unsigned char inportb(unsigned short _port)
//{
//    /* Read from I/O ports to get data from devices such as keyboard */
//    unsigned char rv;
//    asm volatile ("inb %1, %0" : "=a" (rv) : "dN" (_port));
//    return rv;
//}
//
//
//void outportb(unsigned short _port, unsigned char _data)
//{
//    /* Write into I/O ports e.x. change text-mode cursors pos */
//    asm volatile ("outb %1, %0" : : "dN" (_port), "a" (_data));
//}
//
//int irqEnabled(void)
//{
//    /* Return 1 if irq is enabled on current machine
//       Rem: i386 ELF testrun on x86_64 will return 0 anyway */    
//    int f; 
//    asm volatile ("pushf;popl %0":"=g" (f));
//    return f & (1<<9);
//}


struct gdt_entry
{
	unsigned short limit_low;
	unsigned short base_low;
	unsigned char base_middle;
	unsigned char access;
	unsigned char granularity;
	unsigned char base_high;

} __attribute__((packed));
 
struct gdt_ptr
{
	unsigned short limit;
	unsigned int base;

} __attribute__((packed));
 
struct gdt_entry gdt[3];
struct gdt_ptr gp;

//La siguiente funci�n se encarga de establecer los valores de un descriptor de la GDT para un proceso espec�fico
//Recibe, en este caso, de la funci�n gdt_install, los valores asociados a los segmentos en donde se ejecutar� dicho proceso
//Tantos procesos se requieran, ser�n las llamadas a esta funci�n, por lo regular, el primer descriptor es NULL, es decir
//esta funci�n recibe par�metros de 0,0,0,0,0
 
void gdt_set_gate(int num, unsigned long base, unsigned long limit, unsigned char access, unsigned char gran)
{
	gdt[num].base_low = (base & 0xFFFF);
	//	printf ("el valor de gdt[num].base_low = %d \n",gdt[num].base_low );
		printf ("\n\nel valor de gdt[num].base_low = %X \n",gdt[num].base_low );
	gdt[num].base_middle = (base >> 16) & 0xFF;
	//	printf ("el valor de gdt[num].base_middle = %d \n",gdt[num].base_middle );
		printf ("el valor de gdt[num].base_middle = %x \n",gdt[num].base_middle );
	gdt[num].base_high = (base >> 24) & 0xFF;
	//	printf ("el valor de gdt[num].base_high = %d \n",gdt[num].base_high );
		printf ("el valor de gdt[num].base_high = %x \n",gdt[num].base_high );
 
	gdt[num].limit_low = (limit & 0xFFFF);
	//	printf ("el valor de gdt[num].limit_low = %d \n",gdt[num].limit_low );	
		printf ("el valor de gdt[num].limit_low = %x \n",gdt[num].limit_low );			
	gdt[num].granularity = ((limit >> 16) & 0x0F);
 	//	printf ("el valor de gdt[num].granularity = %d \n",gdt[num].granularity );
 		printf ("el valor de gdt[num].granularity = %x \n",gdt[num].granularity ); 		
	gdt[num].granularity |= (gran & 0xF0);
 	//	printf ("el valor de gdt[num].granularity = %d \n",gdt[num].granularity );
 		printf ("el valor de gdt[num].granularity = %x \n",gdt[num].granularity ); 		
	gdt[num].access = access;
 	//	printf ("el valor de gdt[num].access = %d \n",gdt[num].access );
 		printf ("el valor de gdt[num].access = %x \n",gdt[num].access ); 		
}

void gdt_install(void)
{
	gp.limit = (sizeof(struct gdt_entry) * 6) - 1;  //Esta variable es la cantidad de descriptores dentro de la GDT que un proceso requiere para su ejecuci�n
													//Se considera que cada proceso (en este caso el kernel) requiere de utilizar los registros
													//de CS, DS, SS, ES, FS y GS, proporcionados por el procesador X86.
													//La tabla de descriptores Globales cuenta con un total de 8192 descriptores, enumerados del 0 al 8191. 
													//Entonces, la variable limit del apuntador de descritores globales del proceso, en este caso indica
													//como l�mite dentro de esa tabla el valor de 7
	printf ("el valor de gp.limit = %x \n ",gp.limit );
	
	gp.base = (unsigned int)&gdt;					//Esta variable indica la direcci�n base en donde est� ubicado el primer descriptor de la GDT, que es
													//en donde se ubica el primer descriptor asociado al kernel.
													//Para obtener su valor, se toma la direcci�n de la estructura de la GDT, descrita previamente
													//A partir de esa direcci�n de memoria, se coloca la GDT, siendo los primeros ocho descriptores los asociados
													//al primer proceso del SO, en este caso el kernel
													//Tras la ejecuci�n del programa, la localidad de memoria es 0x00407A30. Este valor es el obtenido tras
													//la ejecuci�n del programa en una laptop, por lo que este valor no es la locadlidad de memoria en donde
													//se resguarda la GDT para el caso del kernel cuando arranca en la m�quina
 	printf ("el valor de gp.base = %x \n \n",gp.base );//

	gdt_set_gate(0, 0, 0, 0, 0);					//Se manda a llamar a la funci�n gdt_set_gate en 3 ocasiones, el primero es un segmento NULL
	gdt_set_gate(1, 0, 0xFFFFFFFF, 0x9A, 0xCF);		//Se indica el segmento de c�digo 1001 1010
	gdt_set_gate(2, 0, 0xFFFFFFFF, 0x92, 0xCF);		//Se indica el segmento de datos  1001 0010
 

}

void kprint(char *text)
{
    int i;
    for (i = 0; i < strlen(text); i++)
    {
        putch(text[i]);
    }
}

int main(void)
{
    /* Handle all major errors like division by 0 */
    int r;
    printf ("hola");

    gdt_install();

   kprint("i'm a kernel");
    scanf ("%d",r);
    return 0;
    //idt_install();
    //isrs_install();

    /* Allowing IRQs to happen */
    //irq_install();
    //asm volatile ("sti");

    /* Inits graphic layer */
    //init_video();

    /* Setup PIT */
    //timer_install();

    /* Install keyboard */
    //keyboard_install();

    /* Test welcome string */
   // kprint("i'm a kernel");

    /* In start.asm there's inf loop 'jmp $' but it's only 
       if that below breaks somehow down */

    //for (;;);
}

