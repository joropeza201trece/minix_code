#ifndef __SYSTEM_H
#define __SYSTEM_H

/* MAIN.C */
//extern void *memcpy(void *dest, const void *src, int count);
//extern void *memset(void *dest, int val, int count);
//extern void *memsetw(void *dest, short int val, int count);
//extern int strlen(const char *str);
//extern unsigned char inportb(unsigned short _port);
//extern void outportb(unsigned short _port, unsigned char _data);
//extern int irqEnabled(void);

/* GDT.C && IDT.C */
extern void gdt_install(void);
extern void idt_install(void);
extern void idt_set_gate(unsigned char num, unsigned long base, unsigned short sel, unsigned char flags);
extern void gdt_set_gate(int num, unsigned long base, unsigned long limit, unsigned char access, unsigned char gran);


#endif
